package org.movieprj.controller;

import org.movieprj.domain.MemberVO;
import org.movieprj.service.BoardService;
import org.movieprj.service.MemberService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.movieprj.domain.Criteria;
import org.movieprj.domain.PageDTO;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;
import oracle.jdbc.proxy.annotation.Post;

@Controller
@Log4j
@RequestMapping("/board/*")
@AllArgsConstructor
public class BoardController {
	
	private MemberService memSrvc;
	private BoardService brdSrvc;

	@PostMapping(value="/join")
	public String join(MemberVO member, RedirectAttributes rttr) {
		log.info("BoardController join >> " + member);
		
		memSrvc.insert(member);
		//rttr.addFlashAttribute("result", member.getMemID());
		
		return "redirect:/board/list";
	}
	
	@GetMapping(value="/join")
	public void join() {
		
	}
	
	/*
	 * @GetMapping("/list") public void list() {
	 * 
	 * }
	 */
	
	@GetMapping("/list")
	public void list(Criteria cri, Model model) {
		log.info("list -------- :" + cri);
		model.addAttribute("list",brdSrvc.getList(cri));
//		model.addAttribute("pageMaker",new PageDTO(cri,123));
		int total = brdSrvc.getTotal(cri);
		log.info("total :" + total);
		model.addAttribute("pageMaker", new PageDTO(cri,total));
	}
	
}
