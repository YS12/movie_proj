package org.movieprj.domain;

import java.util.Date;

import lombok.Data;

@Data
public class BoardVO {
	private Long post_id;
	private String post_tit;
	private String post_cont;
	private String mem_nick;
	private Date post_date;
}
